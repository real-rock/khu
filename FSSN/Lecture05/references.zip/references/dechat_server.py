import zmq
import time
import socket
from threading import Thread, local

PORT_NAMESERVER = 9001
PORT_CHAT_PUBLISHER = 9002
PORT_CHAT_COLLECTOR = 9003
PORT_SUBSCRIBE = 9004

def beacon_nameserver(local_ip_addr):
    context = zmq.Context()
    socket = context.socket(zmq.PUB)
    socket.bind("tcp://{0}:{1}".format(local_ip_addr, PORT_NAMESERVER))
    print("local name server bind to tcp://{0}:{1}".format(local_ip_addr, PORT_NAMESERVER))
    while True:
        time.sleep(1)
        msg = "NAMESERVER:{0}".format(local_ip_addr)
        socket.send_string(msg)

def user_manager_nameserver(local_ip_addr):
    user_db = []
    context = zmq.Context()
    socket = context.socket(zmq.REP)
    socket.bind("tcp://{0}:{1}".format(local_ip_addr, PORT_SUBSCRIBE))
    print("local db server activated")
    while True:
        user_req = socket.recv_string().split(":")
        user_db.append(user_req)
        print("user '{0}' from '{1}' registered".format(user_req[1], user_req[0]))
        socket.send_string("ok")

def relay_server_nameserver(local_ip_addr):
    ctx = zmq.Context()
    publisher = ctx.socket(zmq.PUB)
    publisher.bind("tcp://{0}:{1}".format(local_ip_addr, PORT_CHAT_PUBLISHER))
    collector = ctx.socket(zmq.PULL)
    collector.bind("tcp://{0}:{1}".format(local_ip_addr, PORT_CHAT_COLLECTOR))

    while True:
        message = collector.recv()
        print("relay server received: ", message)
        publisher.send_string("RELAY:{0}".format(message))

def get_local_ip():
    """Try to determine the local IP address of the machine."""
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        # Use Google Public DNS server to determine own IP
        sock.connect(('8.8.8.8', 80))
        return sock.getsockname()[0]
    except socket.error:
        try:
            return socket.gethostbyname(socket.gethostname())
        except socket.gaierror:
            return '127.0.0.1'
    finally:
        sock.close() 

def main():
    """Main function."""
    ip_addr = get_local_ip()

    beacon_thread = Thread(target=beacon_nameserver, args=(ip_addr,))
    beacon_thread.start()

    db_thread = Thread(target=user_manager_nameserver, args=(ip_addr,))
    db_thread.start()

    relay_thread = Thread(target=relay_server_nameserver, args=(ip_addr,))
    relay_thread.start()

if __name__ == '__main__':
    main()