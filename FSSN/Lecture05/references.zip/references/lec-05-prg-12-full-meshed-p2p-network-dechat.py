"""Decentralized chat example"""

import zmq
import argparse
import platform
import time

from threading import Thread
from netifaces import interfaces, ifaddresses, AF_INET

try:
    import winreg # for MS Windows
except:
    pass

try:
    raw_input
except NameError:
    raw_input = input

def get_connection_name_WINDONWS(target_name): # for MS Windows
    iface_guids = interfaces()
    iface_names = interfaces_by_name_WINDONWS()
    if target_name in iface_names:
        return iface_guids[iface_names.index(target_name)]
    else:
        return None

def interfaces_by_name_WINDONWS(): # for MS Windows
    iface_guids = interfaces()
    iface_names = ['(unknown)' for i in range(len(iface_guids))]
    reg = winreg.ConnectRegistry(None, winreg.HKEY_LOCAL_MACHINE)
    reg_key = winreg.OpenKey(reg, r'SYSTEM\CurrentControlSet\Control\Network\{4d36e972-e325-11ce-bfc1-08002be10318}')
    for i in range(len(iface_guids)):
        try:
            reg_subkey = winreg.OpenKey(reg_key, iface_guids[i] + r'\Connection')
            iface_names[i] = winreg.QueryValueEx(reg_subkey, 'Name')[0]
        except FileNotFoundError:
            pass
    return iface_names

def listen(masked):
    ctx = zmq.Context.instance()
    listener = ctx.socket(zmq.SUB)
    for last in range(1, 255):
        listener.connect("tcp://{0}.{1}:9000".format(masked, last))
        print("connect to tcp://{0}.{1}:9000".format(masked, last))
    listener.setsockopt(zmq.SUBSCRIBE, b'')
    while True:
        try:
            print(listener.recv_string())
        except (KeyboardInterrupt, zmq.ContextTerminated):
            break

def main():
    parser = argparse.ArgumentParser()
    if platform.system() == 'Windows':
        parser.add_argument("interface", type=str, help="the network interface", choices=interfaces_by_name_WINDONWS(),)
    else:
        parser.add_argument("interface", type=str, help="the network interface", choices=interfaces(),)
    parser.add_argument("user", type=str, default='noname', nargs='?', help="Your username",)
    args = parser.parse_args()
    if platform.system() == 'Windows':
        inet = ifaddresses(get_connection_name_WINDONWS(args.interface))[AF_INET]
    else:
        inet = ifaddresses(args.interface)[AF_INET]
    addr = inet[0]['addr']
    masked = addr.rsplit('.', 1)[0]

    ctx = zmq.Context.instance()

    listen_thread = Thread(target=listen, args=(masked,))
    listen_thread.start()
    
    bcast = ctx.socket(zmq.PUB)
    bcast.bind("tcp://%s:9000" % args.interface)
    print("starting chat on %s:9000 (%s.*)" % (args.interface, masked))

    while True:
        try:
            msg = raw_input()
            bcast.send_string("%s: %s" % (args.user, msg))
        except KeyboardInterrupt:
            break
    bcast.close(linger=0)
    ctx.term()

"""execution example
   python ___.py en1 drsungwon (macos)
   python ___.py Wi-Fi drsungwon (ms windows)
"""

if __name__ == '__main__':
    main()