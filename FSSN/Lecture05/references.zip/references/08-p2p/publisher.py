# source: https://medium.com/@prashunjaveri/node-discovery-and-health-checking-in-a-peer-to-peer-network-using-zeromq-d1735257e80c

import time
import zmq
import socket
import json

def main():
    """main method"""

    # Prepare our context and publisher
    context   = zmq.Context()

    publisher = context.socket(zmq.PUB)
    publisher.bind("tcp://*:5563")

    # wait for connects
    time.sleep(1)

    if True:

        # import host info
        [host_name, host_ip] = get_host_name_and_ip()

        # Write two messages, each with an envelope and content
        # sends
        # 1. heartbeat interval
        # 2. max wait time for response from proxy
        # 3. publisher name
        # 4. publisher ip
        # 5. publisher port
        # 6. publisher group
        # 7. publisher status
        # 8. channel name

        discovery_message = {
            "discovery" : {
                  "publisher": {
                        "header": {
                            "node_id":"213sdfsfs",
                            "node_name": host_name,
                            "node_ip":host_ip,
                            "node_port": 5563,
                            "node_group": "/device",
                            "channel_name": "premium"
                        },
                        "payload": {
                           "message": "publisher_discovery_message"
                        }
                }
            }
        }

        json_string = json.dumps(discovery_message)
        print( json_string )
        publisher.send_multipart([b"channel-one", bytes(host_name, 'utf-8'),bytes(host_ip, 'utf-8'),bytes( json_string, 'utf-8')])


    # We never get here but clean up anyhow
    publisher.close()
    context.term()

def get_host_name_and_ip():
    try:
        host_name = socket.gethostname()
        host_ip = socket.gethostbyname(host_name)
        return [host_name, host_ip]
    except:
        print("Unable to get Hostname and IP")


if __name__ == "__main__":
    main()