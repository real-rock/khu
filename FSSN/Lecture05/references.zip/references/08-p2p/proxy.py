# source: https://medium.com/@prashunjaveri/node-discovery-and-health-checking-in-a-peer-to-peer-network-using-zeromq-d1735257e80c

import zmq
#from org.monkeybrain.routernode import global_state
import json

context = zmq.Context()


# Socket facing producers
frontend = context.socket(zmq.XPUB)
frontend.bind("tcp://*:8100")


# Socket facing consumers
backend = context.socket(zmq.XSUB)
backend.connect("tcp://localhost:5563")

socket = context.socket(zmq.REP)
socket.bind("tcp://*:5555")

ctx = zmq.Context()

#redis = global_state.instance()

# Initialize poll set
poller = zmq.Poller()
poller.register(frontend, zmq.POLLIN)
poller.register(backend, zmq.POLLIN)

# Switch messages between sockets
while True:
    socks = dict(poller.poll())


    if socks.get(frontend) == zmq.POLLIN:
        message = frontend.recv_multipart()
        print("subscriber: "+ str(message))
        backend.send_multipart(message)


    if socks.get(backend) == zmq.POLLIN:
        message = backend.recv_multipart()
        print("publisher: " + str(message))
        meta = json.loads(str(message[3],"utf-8"))
        #redis.set("pnode_"+ meta["discovery"]["publisher"]["header"]["node_id"], str(meta))
        print("pnode_"+ meta["discovery"]["publisher"]["header"]["node_id"], str(meta))
        frontend.send_multipart(message)

    #  Wait for next request from client
    [channel_name,host_name, host_ip, contents] = socket.recv_multipart()
    print("subscriber: [ %s %s %s %s ]" % (channel_name, host_name, host_ip, contents))
    #  Send reply back to client
    meta = json.loads(str(contents, "utf-8"))
    #redis.set("snode_"+ meta["discovery"]["subscriber"]["header"]["node_id"], str(meta))
    print("snode_"+ meta["discovery"]["subscriber"]["header"]["node_id"], str(meta))
    socket.send_string("ACK")

zmq.proxy(frontend, backend)


# We never get here…
frontend.close()
backend.close()
context.term()